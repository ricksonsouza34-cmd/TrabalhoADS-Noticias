// Cole aqui as informações públicas do seu projeto Supabase.
// Nunca coloque uma senha de banco ou chave service_role neste arquivo.
const SUPABASE_URL = "COLE_A_URL_DO_SUPABASE";
const SUPABASE_ANON_KEY = "COLE_A_CHAVE_ANON_PUBLICA";
const supabaseConfigured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("COLE_A");